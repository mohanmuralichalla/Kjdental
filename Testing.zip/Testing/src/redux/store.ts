// src/redux/store.ts
import { configureStore } from '@reduxjs/toolkit';
// import your reducers here

const store = configureStore({
  reducer: {
    // add your reducers here
  },
});

export default store;
